package tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ConferenceTest {

	
	@Before
	public void initializeConferences() {
		
	}
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
