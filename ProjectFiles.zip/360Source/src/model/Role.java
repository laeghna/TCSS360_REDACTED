package model;

public enum Role {
	
	PROGRAMCHAIR,
	SUBPROGRAMCHAIR,
	REVIEWER,
	AUTHOR,
}
